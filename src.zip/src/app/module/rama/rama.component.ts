import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rama',
  templateUrl: './rama.component.html',
  styleUrls: ['./rama.component.scss']
})
export class RamaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
