import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-krishnan',
  templateUrl: './krishnan.component.html',
  styleUrls: ['./krishnan.component.scss']
})
export class KrishnanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
