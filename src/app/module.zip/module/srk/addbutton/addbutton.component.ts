import { Component, OnInit } from '@angular/core';
// import { SrkService } from '../srk.service';

@Component({
  selector: 'app-addbutton',
  templateUrl: './addbutton.component.html',
  styleUrls: ['./addbutton.component.scss']
})
export class AddbuttonComponent implements OnInit {

  constructor() {

   }

  ngOnInit(): void {
    
  }

  
}
