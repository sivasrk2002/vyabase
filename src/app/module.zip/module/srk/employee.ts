export interface Employee {
    name: string;
    id: string;
    number: number;
    role: string;
    status: string;
}
