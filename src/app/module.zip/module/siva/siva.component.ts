import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-siva',
  templateUrl: './siva.component.html',
  styleUrls: ['./siva.component.scss']
})
export class SivaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
